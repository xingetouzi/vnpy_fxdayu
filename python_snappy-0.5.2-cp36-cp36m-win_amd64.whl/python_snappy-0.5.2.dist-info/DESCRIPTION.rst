
Python bindings for the snappy compression library from Google.

More details about Snappy library: http://code.google.com/p/snappy


